# state.md — Live State of "Reading Club"

> This file is updated continuously. If a new AI model starts working on the project, it should read this file right after `AGENTS.md`.

**Last updated:** August 7, 2026

---

## Current phase

**Phase 0 — Setup.** No actual code implementation yet — we're in the planning and foundational docs stage.

---

## Recent decisions

| Date | Decision | Reason |
|---|---|---|
| Aug 7, 2026 | Database on Supabase (managed Postgres only, not Auth, not Edge Functions) | Managed backups/administration without hand-rolling infra |
| Aug 7, 2026 | Backend stays FastAPI (Python), hosted separately on Railway (or Fly.io) | Supabase doesn't host Python; the logic (streak/freeze/fines) is branchy and better suited to Python with full control than RLS |
| Aug 7, 2026 | Frontend hosted on Vercel, separate from the backend | Static build, automatic deploys, no need for a manual VPS/nginx setup |
| Aug 7, 2026 | Two separate Supabase projects (`reading-club-dev` / `reading-club-prod`) | Avoid touching real data during development |
| Aug 7, 2026 | Final name: **Reading Club** — technical slug: `reading-club` | Eslam's final decision |
| Aug 7, 2026 | Backend hosting: Railway | Eslam already has Vercel and Supabase accounts; Railway is a simpler starting point than Fly.io for a solo developer |
| Aug 7, 2026 | All foundational docs written in English | Easier for AI models working on the codebase to parse and follow |
| Aug 8, 2026 | Development happens in Antigravity IDE, using ECC ([affaan-m/ECC](https://github.com/affaan-m/ECC)) for planning/TDD/review/security | Eslam's chosen setup; docs reorganized under `docs/` + `.agent/rules/project-reading-club.md` added since Antigravity doesn't auto-load a root `AGENTS.md` |

See `GOVERNANCE.md` §3 for full context.

---

## Current work

No open task right now. Last thing done: translating all foundational docs to English, reorganizing them under `docs/`, and integrating ECC/Antigravity — added `.agent/rules/project-reading-club.md`, updated `AGENTS.md` (§9) and `GOVERNANCE.md` (§4) to delegate to ECC's agents/skills instead of duplicating them.

---

## Next (per `reading-club-full-plan.md` §15)

Phase 0 still has DB/Backend/Frontend/DevOps foundational tasks (creating Supabase projects, structuring the backend and frontend, first commit, Dockerfile, connecting Railway and Vercel, installing ECC targeting Antigravity).

---

## Open items (need a decision or follow-up)

- WhatsApp Business Cloud API account details (Phase 5) need Meta's approval — worth starting that request early since it can take time, even though actual implementation is a later phase.
- Still need to create a Railway account (Eslam already has Vercel and Supabase).
- ECC not yet installed into the actual repo — run `./install.sh --target antigravity typescript python` from a clone of the ECC repo, then verify with `node scripts/doctor.js --target antigravity`.

---

## Session log

### Session — August 8, 2026
- Done: reorganized all docs under `docs/` to match the documented repo structure.
- Done: investigated ECC ([affaan-m/ECC](https://github.com/affaan-m/ECC)) and its Antigravity integration (`.agent/` directory convention).
- Done: added `.agent/rules/project-reading-club.md` (condensed rules Antigravity auto-loads), since Antigravity doesn't read a root `AGENTS.md`.
- Done: updated `AGENTS.md` (§9) and `GOVERNANCE.md` (§4) to delegate planning/TDD/review/security to ECC's agents instead of duplicating them.
- **Suggested next step:** clone ECC, run `./install.sh --target antigravity typescript python` against this repo, then `node scripts/doctor.js --target antigravity` to confirm.

### Session — August 7, 2026
- Done: the full plan (`reading-club-full-plan.md`) with all 15 sections.
- Done: infrastructure decision (Supabase + Railway + Vercel) after discussing the options.
- Done: the five foundational docs.
- Done: renamed the project to "Reading Club" and translated all docs to English.
- **Suggested next step:** Start actual Phase 0 work — creating Supabase projects and structuring the repo.
